let garden;
let button;
let button2;
let button3;


function preload() {
  garden = loadImage('pictures/unknown.png');
}
function setup() {
  createCanvas(400, 400);
   button = createButton('Slicing');
  button.position(40, 340);
  button2 = createButton('Gardening');
   button2.position(150,340);
  button3 = createButton('Tracing');
  button3.position(300,340);
  

  circle(100, 250, 100);

}

function draw() {
  image(garden,0,0);
}