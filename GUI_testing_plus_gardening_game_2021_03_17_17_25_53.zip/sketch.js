// BY MEGAN BEAUDOIN


//***VARIABLES:***

//GUI
let sky,trees, cloud;
let cloudx = 0, cloudx1 = 300, cloudx2 = 150;
let homeplant;

//TRACING
let tracebg;

//GARDENING
let gardenbg;
let dirt1,dirt2,dirt3,dirt4,dirt5,dirt6;
let seed,sprouticon,watercan,curvearrow;
let seedx=185, seedy=70, canx = 240, cany = 75;
let plantphase = 1, plantDragged = 0, directionRight = 0, coveredleft = 0, coveredright = 0;
let deltax, deltay;
let doneplant = 0;
let planttime=0;

//SLICING
let slicebg;

//OTHER
let whichclick = 'none';
let homebttn, startbttn;
let arrowleft, arrowright;
let tutorial = 0;


function preload() {
  //GUI
  sky = loadImage('Pictures/backgroundfile.png');
  trees = loadImage('Pictures/trees.png');
  cloud = loadImage('Pictures/cloud.png');
  homeplant = loadImage('Pictures/homeplant.png');
  
  //TRACING
  tracebg = loadImage('Pictures/tracingbackground.png');
  
  //GARDENING
  gardenbg = loadImage('Pictures/gardenbackground.png');
  dirt1 = loadImage('Pictures/garden1dirt.png');
  dirt2 = loadImage('Pictures/garden2left.png');
  dirt3 = loadImage('Pictures/garden3right.png');
  dirt4 = loadImage('Pictures/garden4covered.png');
  dirt5 = loadImage('Pictures/garden5watered.png');
  dirt6 = loadImage('Pictures/garden6plant.png');
  seed = loadImage('Pictures/seed.png');
  sprouticon = loadImage('Pictures/sprouticon.png');
  watercan = loadImage('Pictures/wateringcan.png');
  curvearrow = loadImage('Pictures/curvearrow.png')
  
  //SLICING
  slicebg = loadImage('Pictures/slicingbackground.png');
  
  //OTHER
  homebttn = loadImage('Pictures/homebutton.png');
  startbttn = loadImage('Pictures/startbutton.png');
  arrowleft = loadImage('Pictures/arrowleft.png');
  arrowright = loadImage('Pictures/arrowright.png');
}

function setup() {
  createCanvas(400,400);
}

function draw() {
  
  //GUI
  if (whichclick == 'none') {
    image(sky, 0, 0);
    image(cloud, cloudx, 0);
    image(cloud, cloudx1, 30);
    image(cloud, cloudx2, 60);
    image(trees, 0, 0);
    
    textSize(14)
    text(' Would you like to \ntrace cloud shapes?',235,60)
    text('           Would \n       you like \nto garden?',200,360)
    text('  Would you like \nto prepare lunch?',130,300)
    //cloud bs
    if (cloudx < 400) {
      cloudx++;
    }
    else {
      cloudx = -100;
    }
    if (cloudx1 < 400) {
      cloudx1++;
    }
    else {
      cloudx1 = -100;
    }
    if (cloudx2 < 400) {
      cloudx2++;
    }
    else {
      cloudx2 = -100;
    }
    
    //plants!
    switch(doneplant){
      case 0:
        break;
      case 1:
        image(homeplant,336,302);
        break;
      case 2:
        image(homeplant,336,302);
        image(homeplant,378,302);
        break;
      case 3:
        image(homeplant,336,302);
        image(homeplant,378,302);
        image(homeplant,330,320);
        break;
      case 4:
        image(homeplant,336,302);
        image(homeplant,378,302);
        image(homeplant,330,320);
        image(homeplant,377,320);
        break;
      case 5:
        image(homeplant,336,302);
        image(homeplant,378,302);
        image(homeplant,330,320);
        image(homeplant,377,320);
        image(homeplant,324,339);
        break;
      case 6:
        image(homeplant,336,302);
        image(homeplant,378,302);
        image(homeplant,330,320);
        image(homeplant,377,320);
        image(homeplant,324,339);
        image(homeplant,374,340);
        break;
      case 7:
        image(homeplant,336,302);
        image(homeplant,378,302);
        image(homeplant,330,320);
        image(homeplant,377,320);
        image(homeplant,324,339);
        image(homeplant,374,340);
        image(homeplant,318,359);
        break;
      case 8:
        image(homeplant,336,302);
        image(homeplant,378,302);
        image(homeplant,330,320);
        image(homeplant,377,320);
        image(homeplant,324,339);
        image(homeplant,374,340);
        image(homeplant,318,359);
        image(homeplant,373,360);
        break;
      case 9:
        image(homeplant,336,302);
        image(homeplant,378,302);
        image(homeplant,330,320);
        image(homeplant,377,320);
        image(homeplant,324,339);
        image(homeplant,374,340);
        image(homeplant,318,359);
        image(homeplant,373,360);
        image(homeplant,310,379);
        break;
      default:
        image(homeplant,336,302);
        image(homeplant,378,302);
        image(homeplant,330,320);
        image(homeplant,377,320);
        image(homeplant,324,339);
        image(homeplant,374,340);
        image(homeplant,318,359);
        image(homeplant,373,360);
        image(homeplant,310,379);
        image(homeplant,370,380);
    }
  }
  
  //TRACING
  if (whichclick == 'cloud') {
    image(tracebg, 0, 0);
    if (tutorial == 1){
      textSize(20);
      text("This it the Tracing Game!\nTrace the shapes \nindicated on the clouds \nto score points!",100,100)
      image(homebttn, 25,300);
      image(startbttn, 225,300);
    }
    
    else if (tutorial == 0){
      image(homebttn, 225,300);
      textSize(25);
      text('Game Starts!',130,200);
      
      // PUT CODE FOR GAME HERE!
    }
  }
  
  //GARDENING
  if (whichclick == 'garden') {
    image(gardenbg, 0, 0);
    if (tutorial == 1){
      textSize(20);
      text("This it the Gardening Game!\nFollow the instructions \nto plant seeds \nand help the garden grow!",100,100)
      image(homebttn, 25,300);
      image(startbttn, 225,300);
    }
    
    else if (tutorial == 0){
      
      textSize(25);
      text('Game Starts!',130,200);
      if (plantphase == 1){
        image(dirt1,0,0);
        image(seed,seedx, seedy);
        text ('Plant the seed in the hole!',50,60);
        if (seedx < 205 && seedx > 170 && seedy < 200 && seedy > 175) {
          seedx = 185;
          seedy = 187;
          plantphase = 2;
        }
      }
      else if (plantphase == 2){
        image (dirt1,0,0);
        image (seed, seedx,seedy);
        text ('Cover the seed with dirt!\nFollow the arrows!',50,60);
        image (arrowleft,240,130);
        image (arrowright,0,130);
        
        if (directionRight == 1 && deltax > 150) {
          if (deltay > 25 || deltay < -25) {
            text('try to keep steady!', 100,100)
          }
          else {
            coveredleft = 1;
          }
        }
        if (directionRight == 2 && deltax < -150) {
          if (deltay > 25 || deltay < -25) {
            text('try to keep steady!', 100,100)
          }
          else {
            coveredright = 1;
          }
        }
        if (coveredleft != 0 || coveredright != 0) {
          plantphase = 3;
        }
      }
      else if (plantphase == 3){
        if (coveredleft == 1) {
          image(dirt2,0,0); //left
          image(arrowleft,240,130);
        }
        else {
          image(dirt3,0,0); //right
          image(arrowright,0,130);
        }
        text ('Cover the seed with dirt!\nFollow the arrows!',50,60);
        if (directionRight == 1 && deltax > 150) {
          if (deltay > 25 || deltay < -25) {
            text('try to keep steady!', 100,100)
          }
          else {
            coveredleft = 1;
          }
        }
        if (directionRight == 2 && deltax < -150) {
          if (deltay > 25 || deltay < -25) {
            text('try to keep steady!', 100,100)
          }
          else {
            coveredright = 1;
          }
        }
        if (coveredleft == coveredright) {
          plantphase = 4;
          coveredleft = 0;
          coveredright = 0;
          plantDragged = 0;
          deltax=0;
          deltay=0;
        }
      }
      else if (plantphase == 4){

        image(dirt4,0,0);
        text ('Water the plant!',80,60);
        image(watercan,canx,cany);
        image(curvearrow,150,50);
        if(deltax<-90 && deltay>90) {
          plantphase=5;
        }
        
      }
      else if (plantphase == 5){
        image(dirt5,0,0);
        planttime++;
        text('Great job!',80,60);
        if (planttime > 100) {
          plantphase = 6;
          planttime = 0;
          doneplant++;
        }
        
      }
      else {
        image(dirt6,0,0);
        planttime++;
        if (planttime > 150) {
          plantphase = 1;
          planttime = 0;
          
          seedx = 185;
          seedy = 70;
        }
        
      }
      image(homebttn, 225,300);
      image(sprouticon, 10,340)
      text ('x',50,380)
      text (doneplant,70,380)
    }
  }
  
  //SLICING
  if (whichclick == 'blanket') {
    image(slicebg, 0, 0);
    if (tutorial == 1){
      textSize(20);
      text("This it the Slicing Game!\nFollow instructions \nto prepare lunch \nto score points!",100,100)
      image(homebttn, 25,300);
      image(startbttn, 225,300);
    }
    
    else if (tutorial == 0){
      image(homebttn, 225,300);
      textSize(25);
      text('Game Starts!',130,200);
      
      // PUT CODE FOR GAME HERE!
    }
  }
  
  
  /*//x&y coordinates TEMPORARY 
  textSize(28);
  text(mouseX, 10, 30);
  text(mouseY, 10, 50);*/

}

function mouseClicked(){
  //GUI
  if (whichclick == 'none') {
    //blanket
    if (mouseX < 283 && mouseX > 120 && mouseY < 286 && mouseY > 248) {
      whichclick = 'blanket';
      tutorial = 1;
    }
    //garden
    else if (mouseX > 280 && mouseY > 300 && mouseX < 400 && mouseY < 400) {
      whichclick = 'garden';
      tutorial = 1;
      fill('white');
    }
    //cloud
    else if (mouseX < 355 && mouseX > 230 && mouseY < 85 && mouseY > 28) {
      whichclick = 'cloud';
      tutorial = 1;
    }
    else {
      whichclick = 'none';
    }
  }
  
  //TRACING
  else if (whichclick == 'cloud') {
    //tutorial screen
    if (tutorial == 1) {
      //home button
      if (mouseX < 170 && mouseX > 30 && mouseY < 365 && mouseY > 300) {
        whichclick = 'none';
        tutorial = 1;
      }
      //start button
      else if (mouseX < 370 && mouseX > 230 && mouseY < 365 && mouseY > 300) {
        tutorial = 0;
      }
    }
    //game
    else{
      if (mouseX < 370 && mouseX > 230 && mouseY < 365 && mouseY > 300) {
        whichclick = 'none';
        
        
      }
    }
  }
  
  //GARDENING
  else if (whichclick == 'garden') {
    //tutorial screen
    if (tutorial == 1) {
      //home button
      if (mouseX < 170 && mouseX > 30 && mouseY < 365 && mouseY > 300) {
        whichclick = 'none';
        tutorial = 1;
        fill('black');
      }
      //start button
      else if (mouseX < 370 && mouseX > 230 && mouseY < 365 && mouseY > 300) {
        tutorial = 0;
      }
    }
    
    //game
    else{
      if (plantphase == 1){
        if (mouseX < (seedx + 20) && mouseX > seedx && mouseY < (seedy + 45) && mouseY > seedy) {
          text('Click and drag!',60,100)
        }
      }
      if (mouseX < 370 && mouseX > 230 && mouseY < 365 && mouseY > 300) {
        whichclick = 'none';
        fill('black');
      }
    }
    
  }
  
  //SLICING
  else if (whichclick == 'blanket') {
    //tutorial screen
    if (tutorial == 1) {
      //home button
      if (mouseX < 170 && mouseX > 30 && mouseY < 365 && mouseY > 300) {
        whichclick = 'none';
        tutorial = 1;
      }
      //start button
      else if (mouseX < 370 && mouseX > 230 && mouseY < 365 && mouseY > 300) {
        tutorial = 0;
      }
    }
    //game
    else{
      if (mouseX < 370 && mouseX > 230 && mouseY < 365 && mouseY > 300) {
        whichclick = 'none';
        
        
      }
    }
    
  }
}
  
function mousePressed() {
  //GARDENING
  if (whichclick == 'garden') {
    if (plantphase == 1){
      if(mouseX < (seedx + 20) && mouseX > seedx && mouseY < (seedy + 45) && mouseY > seedy)
        plantDragged = 1;
    }
    if (plantphase == 2 || plantphase == 3){
      if (mouseX < 100 && mouseX > 0 && mouseY < 300 && mouseY > 30){
        plantDragged = 1;
        directionRight = 1;
      }
      else if (mouseX < 400 && mouseX > 300 && mouseY < 300 && mouseY > 30) {
        plantDragged = 1;
        directionRight = 2;
      }
    }
    if (plantphase==4) {
      if (mouseX < (canx+140) && mouseX > canx && mouseY < (cany + 90) && mouseY > cany) {
        plantDragged = 1;
      }
    }
  }
}
function mouseDragged() {
  // GARDENING
  if (whichclick == 'garden') {
    
    if (plantphase == 1 && plantDragged == 1) {
      seedx = seedx + movedX;
      seedy = seedy + movedY;
    }
    if (plantphase == 2 || plantphase == 3 && plantDragged == 1) {
      deltax += movedX;
      deltay += movedY;
    }
    else if (plantphase == 4 && plantDragged == 1) {
      deltax += movedX;
      deltay += movedY;
      
    }
  }  
}
function mouseReleased() {
  // GARDENING
  if (whichclick == 'garden') {
    deltax = 0;
    deltay = 0;
    directionRight = 0;
    plantDragged = 0;
  }
}
  
  